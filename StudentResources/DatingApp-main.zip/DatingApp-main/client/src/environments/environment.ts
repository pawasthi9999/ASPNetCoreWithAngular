export const environment = {
    production: true,
    apiUrl: 'api/',
    hubsUrl: 'hubs/',
};
