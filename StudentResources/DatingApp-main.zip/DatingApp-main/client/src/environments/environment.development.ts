export const environment = {
    production: false,
    apiUrl: 'https://localhost:5001/api/',
    hubsUrl: 'https://localhost:5001/hubs/',
};
